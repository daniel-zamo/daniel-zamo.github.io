---
title: "Configuración de NTP con Chrony en RHEL/CentOS"
description: "Procedimiento estándar para configurar sincronización de tiempo usando Chrony en servidores de producción Red Hat Enterprise Linux"
date: 2026-01-31
tags: ['ntp', 'chrony', 'time-sync', 'rhel', 'centos']
category: 'sop'
systems: ['linux']
difficulty: 'beginner'
author: 'Daniel Zamo'
lang: 'es'
keywords: ['ntp', 'chrony', 'time synchronization', 'rhel', 'centos', 'timekeeping']
---

## 🎯 Objetivo

Configurar y validar la sincronización de tiempo en servidores Linux usando Chrony, reemplazando al antiguo servicio NTPd.

## 📋 Contexto

**Chrony** es la implementación moderna de NTP (Network Time Protocol) que viene por defecto en RHEL 8+ y CentOS 8+. Ofrece mejor rendimiento que NTPd en sistemas con conectividad intermitente y arranques/suspensiones frecuentes.

### Casos de Uso
- Servidores de producción que requieren sincronización precisa de tiempo
- Sistemas en redes con latencia variable
- Entornos de virtualización
- Clústeres de alta disponibilidad

## 📋 Prerrequisitos

- Sistema RHEL 8+, CentOS 8+, Rocky Linux 8+ o Alma Linux 8+
- Acceso root o privilegios sudo
- Conectividad de red a servidores NTP (puertos UDP 123)
- Firewall configurado para permitir tráfico NTP

## 🔧 Procedimiento

### 1. Instalación de Chrony

Chrony viene preinstalado en RHEL 8+, pero si no está presente:

```bash
# Instalar Chrony
sudo dnf install -y chrony

# Verificar versión instalada
chronyc -v
```

**Salida esperada:**
```
chrony version 4.2
```

### 2. Configuración de Servidores NTP

Editar el archivo de configuración principal:

```bash
sudo nano /etc/chrony.conf
```

**Configuración recomendada para entorno corporativo:**

```ini
# Servidores NTP internos (ajustar a tu infraestructura)
server ntp1.empresa.local iburst
server ntp2.empresa.local iburst

# Servidores NTP públicos como respaldo (opcional)
server 0.pool.ntp.org iburst
server 1.pool.ntp.org iburst

# Permitir que el sistema ajuste el reloj del sistema
# incluso si el offset es grande
makestep 1.0 3

# Ubicación del archivo drift (corrección de deriva del reloj)
driftfile /var/lib/chrony/drift

# Habilitar logs
logdir /var/log/chrony

# Permitir sincronización de clientes en la red local (opcional)
# Descomentar si este servidor actuará como NTP para otros hosts
# allow 192.168.1.0/24

# Deshabilitar comandos remotos por seguridad
cmdport 0
```

**Parámetros importantes:**

| Parámetro | Descripción |
|-----------|-------------|
| `iburst` | Envía una ráfaga de 8 paquetes para sincronización inicial rápida |
| `makestep 1.0 3` | Permite ajustes de tiempo mayores a 1 segundo en las primeras 3 actualizaciones |
| `driftfile` | Almacena información sobre la deriva del reloj del sistema |
| `cmdport 0` | Deshabilita acceso remoto al demonio para mayor seguridad |

### 3. Configuración de Firewall

Si el firewall está activo, permitir tráfico NTP:

```bash
# Verificar estado del firewall
sudo firewall-cmd --state

# Permitir servicio NTP permanentemente
sudo firewall-cmd --permanent --add-service=ntp

# Recargar configuración del firewall
sudo firewall-cmd --reload

# Verificar regla aplicada
sudo firewall-cmd --list-services
```

### 4. Habilitar y Arrancar Servicio

```bash
# Habilitar Chrony para inicio automático
sudo systemctl enable chronyd

# Iniciar servicio
sudo systemctl start chronyd

# Verificar estado del servicio
sudo systemctl status chronyd
```

**Salida esperada:**
```
● chronyd.service - NTP client/server
   Loaded: loaded (/usr/lib/systemd/system/chronyd.service; enabled)
   Active: active (running) since Fri 2026-01-31 10:30:15 CET; 2min ago
```

## ✅ Validación

### 1. Verificar Fuentes de Tiempo

```bash
chronyc sources -v
```

**Salida esperada:**
```
  .-- Source mode  '^' = server, '=' = peer, '#' = local clock.
 / .- Source state '*' = current best, '+' = combined, '-' = not combined,
| /             'x' = may be in error, '~' = too variable, '?' = unusable.
||                                                 .- xxxx [ yyyy ] +/- zzzz
||      Reachability register (octal) -.           |  xxxx = adjusted offset,
||      Log2(Polling interval) --.      |          |  yyyy = measured offset,
||                                \     |          |  zzzz = estimated error.
||                                 |    |           \
MS Name/IP address         Stratum Poll Reach LastRx Last sample               
===============================================================================
^* ntp1.empresa.local           2   6   377    34   +123us[ +156us] +/-   15ms
^+ ntp2.empresa.local           2   6   377    35   -234us[ -201us] +/-   18ms
```

**Interpretación:**
- `^*` = Fuente actualmente en uso (mejor servidor)
- `^+` = Servidor combinado en el cálculo de tiempo
- `377` en "Reach" = Conectividad perfecta (8 intentos exitosos)

### 2. Verificar Sincronización

```bash
chronyc tracking
```

**Salida esperada:**
```
Reference ID    : C0A80A01 (ntp1.empresa.local)
Stratum         : 3
Ref time (UTC)  : Fri Jan 31 09:30:45 2026
System time     : 0.000000123 seconds fast of NTP time
Last offset     : +0.000000234 seconds
RMS offset      : 0.000000345 seconds
Frequency       : 5.123 ppm slow
Residual freq   : +0.002 ppm
Skew            : 0.012 ppm
Root delay      : 0.015234567 seconds
Root dispersion : 0.000987654 seconds
Update interval : 64.3 seconds
Leap status     : Normal
```

**Valores saludables:**
- `System time` < 1ms (menos de 0.001 segundos)
- `RMS offset` < 10ms
- `Leap status`: Normal

### 3. Verificar Sincronización con Systemd

```bash
timedatectl status
```

**Salida esperada:**
```
               Local time: Fri 2026-01-31 10:35:22 CET
           Universal time: Fri 2026-01-31 09:35:22 UTC
                 RTC time: Fri 2026-01-31 09:35:22
                Time zone: Europe/Madrid (CET, +0100)
System clock synchronized: yes
              NTP service: active
          RTC in local TZ: no
```

**Verificar:**
- `System clock synchronized: yes` ✅
- `NTP service: active` ✅

## 🚨 Troubleshooting

### Problema 1: Chrony no sincroniza

**Síntomas:**
```bash
chronyc tracking
# Muestra: System time desviado por segundos o minutos
```

**Diagnóstico:**
```bash
# Verificar logs
sudo journalctl -u chronyd -n 50

# Verificar conectividad a servidores NTP
chronyc sources
# Buscar '?' en la columna de estado
```

**Soluciones:**

1. **Firewall bloqueando NTP:**
```bash
sudo firewall-cmd --permanent --add-service=ntp
sudo firewall-cmd --reload
```

2. **Servidores NTP inalcanzables:**
```bash
# Probar conectividad manual
sudo chronyc -a makestep
sudo systemctl restart chronyd
```

3. **Offset muy grande:**
```bash
# Forzar ajuste de tiempo
sudo chronyc -a makestep
```

### Problema 2: Deriva constante del reloj

**Causa:** Hardware del reloj del sistema defectuoso o VM con mala configuración de recursos.

**Solución:**
```bash
# En sistemas virtualizados, asegurar que VMware Tools/qemu-guest-agent está instalado
sudo systemctl status vmtoolsd
# o
sudo systemctl status qemu-guest-agent

# Verificar driftfile
cat /var/lib/chrony/drift
# Si el valor es > 100 ppm, posible problema de hardware
```

### Problema 3: Servicio falla al iniciar

**Diagnóstico:**
```bash
sudo systemctl status chronyd -l
sudo journalctl -xe -u chronyd
```

**Soluciones comunes:**
- Verificar sintaxis de `/etc/chrony.conf`
- Asegurar que no hay otro servicio NTP corriendo (NTPd)
```bash
sudo systemctl stop ntpd
sudo systemctl disable ntpd
```

## 📊 Monitoreo

### Comando de Monitoreo Continuo

```bash
# Monitorear estadísticas en tiempo real
watch -n 10 'chronyc tracking && echo "---" && chronyc sources'
```

### Script de Verificación Rápida

```bash
#!/bin/bash
# check-ntp-health.sh
echo "=== NTP Health Check ==="
echo ""
echo "Service Status:"
systemctl is-active chronyd
echo ""
echo "Synchronization Status:"
timedatectl | grep "System clock synchronized"
echo ""
echo "Current Offset:"
chronyc tracking | grep "System time"
echo ""
echo "NTP Sources:"
chronyc sources | grep "^\^"
```

## 🔒 Consideraciones de Seguridad

1. **Deshabilitar comandos remotos:**
   - Mantener `cmdport 0` en la configuración

2. **Limitar servidores NTP:**
   - Usar servidores NTP internos cuando sea posible
   - Evitar servidores NTP públicos no confiables

3. **Firewall:**
   - Permitir tráfico NTP solo desde/hacia servidores conocidos
   - Regla de firewall recomendada:
   ```bash
   sudo firewall-cmd --permanent --add-rich-rule='rule family="ipv4" source address="192.168.1.0/24" service name="ntp" accept'
   ```

4. **Logs:**
   - Revisar periódicamente `/var/log/chrony/` para actividad anómala

## 📚 Referencias

- [Documentación oficial de Chrony](https://chrony.tuxfamily.org/documentation.html)
- [Red Hat: Configuring NTP using chrony](https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux/8/html/configuring_basic_system_settings/using-chrony-to-configure-ntp)
- [Comparación Chrony vs NTPd](https://chrony.tuxfamily.org/comparison.html)
- RFC 5905: Network Time Protocol Version 4

## 📝 Historial de Cambios

| Fecha | Versión | Cambios |
|-------|---------|---------|
| 2026-01-31 | 1.0 | Documento inicial creado |

---

**Nivel de Criticidad:** Alta - La sincronización de tiempo es crítica para:
- Logs correlacionados
- Certificados SSL/TLS
- Kerberos/Active Directory
- Bases de datos distribuidas
- Sistemas de respaldo

**Tiempo Estimado de Implementación:** 15-20 minutos

**Sistemas Compatibles:**
- ✅ RHEL 8+
- ✅ CentOS 8+ / CentOS Stream
- ✅ Rocky Linux 8+
- ✅ AlmaLinux 8+
- ✅ Fedora 28+
- ⚠️ RHEL 7 (requiere instalación manual)
