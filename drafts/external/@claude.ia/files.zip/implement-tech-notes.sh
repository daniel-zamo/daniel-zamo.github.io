#!/bin/bash
# ============================================
# IMPLEMENTACIÓN RÁPIDA: Sección Tech Notes
# ============================================
# 
# Este script ejecuta todos los pasos necesarios para implementar
# la nueva sección de Notas Técnicas en tu sitio Astro + Starlight
#
# IMPORTANTE: Revisa cada sección antes de ejecutar

set -e  # Detener en caso de error

echo "🚀 Iniciando implementación de Tech Notes..."

# ============================================
# PASO 1: Crear estructura de directorios
# ============================================
echo ""
echo "📁 [PASO 1/5] Creando estructura de directorios..."

mkdir -p src/content/tech-notes/{es,en}/{sop,troubleshooting,howto}
mkdir -p src/pages/tech-notes
mkdir -p src/layouts

echo "   ✅ Directorios creados exitosamente"

# ============================================
# PASO 2: Migrar notas existentes
# ============================================
echo ""
echo "📦 [PASO 2/5] Migrando notas existentes..."

# Verificar si existen las notas antes de mover
if [ -d "src/content/docs/en/notes" ]; then
    echo "   → Migrando notas en inglés..."
    
    if [ -f "src/content/docs/en/notes/wsl-export-guide.mdx" ]; then
        mv src/content/docs/en/notes/wsl-export-guide.mdx src/content/tech-notes/en/howto/
    fi
    
    if [ -f "src/content/docs/en/notes/wsl-migration-backup-strategy.mdx" ]; then
        mv src/content/docs/en/notes/wsl-migration-backup-strategy.mdx src/content/tech-notes/en/sop/
    fi
    
    if [ -f "src/content/docs/en/notes/wsl-restoration-guide.mdx" ]; then
        mv src/content/docs/en/notes/wsl-restoration-guide.mdx src/content/tech-notes/en/howto/
    fi
    
    # Eliminar directorio vacío
    rmdir src/content/docs/en/notes 2>/dev/null || true
fi

if [ -d "src/content/docs/es/notes" ]; then
    echo "   → Migrando notas en español..."
    
    if [ -f "src/content/docs/es/notes/wsl-export-guide.mdx" ]; then
        mv src/content/docs/es/notes/wsl-export-guide.mdx src/content/tech-notes/es/howto/
    fi
    
    if [ -f "src/content/docs/es/notes/wsl-migration-backup-strategy.mdx" ]; then
        mv src/content/docs/es/notes/wsl-migration-backup-strategy.mdx src/content/tech-notes/es/sop/
    fi
    
    if [ -f "src/content/docs/es/notes/wsl-restoration-guide.mdx" ]; then
        mv src/content/docs/es/notes/wsl-restoration-guide.mdx src/content/tech-notes/es/howto/
    fi
    
    # Eliminar directorio vacío
    rmdir src/content/docs/es/notes 2>/dev/null || true
fi

echo "   ✅ Migración completada"

# ============================================
# PASO 3: Actualizar archivos de configuración
# ============================================
echo ""
echo "⚙️  [PASO 3/5] Actualizando archivos de configuración..."
echo ""
echo "   ⚠️  ACCIÓN MANUAL REQUERIDA:"
echo "   Los siguientes archivos deben ser actualizados manualmente:"
echo ""
echo "   1️⃣  src/content.config.ts"
echo "      → Añadir colección 'tech-notes' (ver guía detallada)"
echo ""
echo "   2️⃣  astro.config.mjs"
echo "      → Actualizar sidebar con enlace a Tech Notes"
echo "      → Eliminar referencia a autogenerate: { directory: 'notes' }"
echo ""
echo "   3️⃣  src/pages/rss.xml.js"
echo "      → Cambiar getCollection('docs') por getCollection('tech-notes')"
echo ""
echo "   📖 Consulta la guía completa: TECH-NOTES-IMPLEMENTATION-GUIDE.md"
echo ""

read -p "   ¿Has actualizado los archivos de configuración? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "   ⏸️  Ejecución pausada. Actualiza los archivos y vuelve a ejecutar."
    exit 1
fi

# ============================================
# PASO 4: Crear archivos de páginas
# ============================================
echo ""
echo "📄 [PASO 4/5] Creando archivos de páginas..."
echo "   ⚠️  Los archivos src/pages/tech-notes/index.astro y"
echo "      src/layouts/TechNoteLayout.astro deben ser creados manualmente."
echo "   📖 El código completo está en la guía de implementación."
echo ""

# ============================================
# PASO 5: Actualizar frontmatter de notas migradas
# ============================================
echo ""
echo "✏️  [PASO 5/5] Actualizando frontmatter de notas..."
echo ""
echo "   ⚠️  ACCIÓN MANUAL REQUERIDA:"
echo "   Debes actualizar el frontmatter de cada nota migrada."
echo "   Ejemplo de frontmatter necesario:"
echo ""
cat << 'EOF'
---
title: "Título de la Nota"
description: "Descripción breve"
date: 2026-01-31
tags: ['tag1', 'tag2']
category: 'sop'
systems: ['linux']
difficulty: 'intermediate'
author: 'Daniel Zamo'
lang: 'es'
---
EOF
echo ""
echo "   📖 Ver ejemplos completos en la guía de implementación."
echo ""

# ============================================
# VERIFICACIÓN FINAL
# ============================================
echo ""
echo "🎯 [VERIFICACIÓN] Ejecutando verificaciones..."

# Verificar estructura de directorios
echo "   → Verificando estructura de directorios..."
if [ -d "src/content/tech-notes/es" ] && [ -d "src/content/tech-notes/en" ]; then
    echo "   ✅ Estructura de directorios correcta"
else
    echo "   ❌ ERROR: Directorios no encontrados"
    exit 1
fi

# Verificar que no existan las carpetas antiguas
if [ -d "src/content/docs/en/notes" ] || [ -d "src/content/docs/es/notes" ]; then
    echo "   ⚠️  ADVERTENCIA: Carpetas 'notes' antiguas aún existen"
else
    echo "   ✅ Carpetas antiguas eliminadas correctamente"
fi

echo ""
echo "============================================"
echo "✨ IMPLEMENTACIÓN COMPLETADA"
echo "============================================"
echo ""
echo "📝 PRÓXIMOS PASOS:"
echo ""
echo "1. Revisa y completa las actualizaciones manuales en:"
echo "   - src/content.config.ts"
echo "   - astro.config.mjs"
echo "   - src/pages/rss.xml.js"
echo ""
echo "2. Crea los archivos de páginas:"
echo "   - src/pages/tech-notes/index.astro"
echo "   - src/layouts/TechNoteLayout.astro (opcional)"
echo ""
echo "3. Actualiza el frontmatter de las notas migradas"
echo ""
echo "4. Ejecuta las pruebas:"
echo "   npm run build"
echo "   npm run dev"
echo ""
echo "5. Verifica las rutas:"
echo "   http://localhost:4321/es/tech-notes/"
echo "   http://localhost:4321/en/tech-notes/"
echo ""
echo "📖 Consulta la guía completa: TECH-NOTES-IMPLEMENTATION-GUIDE.md"
echo ""
