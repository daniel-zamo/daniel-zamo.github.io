#!/bin/bash
# ============================================
# DIAGNÓSTICO Y CORRECCIÓN DE RUTAS TECH-NOTES
# ============================================

set -e

echo "🔍 DIAGNÓSTICO DEL PROBLEMA DE RUTAS"
echo "===================================="
echo ""

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# ============================================
# 1. VERIFICAR ESTRUCTURA DE DIRECTORIOS
# ============================================
echo "📁 [1/6] Verificando estructura de directorios..."
echo ""

if [ -d "src/content/tech-notes" ]; then
    echo -e "${GREEN}✓${NC} Directorio src/content/tech-notes existe"
    echo "   Contenido:"
    tree -L 2 src/content/tech-notes/ 2>/dev/null || find src/content/tech-notes -type d -maxdepth 2
else
    echo -e "${RED}✗${NC} Directorio src/content/tech-notes NO existe"
    echo "   Creándolo..."
    mkdir -p src/content/tech-notes/{es,en}/{sop,troubleshooting,howto}
    echo -e "${GREEN}✓${NC} Directorios creados"
fi

echo ""

# ============================================
# 2. VERIFICAR ARCHIVO DE PÁGINAS
# ============================================
echo "📄 [2/6] Verificando archivo de índice..."
echo ""

if [ -f "src/pages/tech-notes/index.astro" ]; then
    echo -e "${GREEN}✓${NC} Archivo src/pages/tech-notes/index.astro existe"
else
    echo -e "${RED}✗${NC} Archivo src/pages/tech-notes/index.astro NO existe"
    echo "   Este es el problema principal - creando archivo..."
    
    mkdir -p src/pages/tech-notes
    
    cat > src/pages/tech-notes/index.astro << 'ASTROEOF'
---
// ARCHIVO TEMPORAL DE DIAGNÓSTICO
// Reemplazar con el contenido completo de la guía
import { getCollection } from 'astro:content';

const allNotes = await getCollection('tech-notes');
const currentLang = 'es'; // Simplificado para diagnóstico
const notes = allNotes.filter(n => n.data.lang === currentLang);
---

<html>
<head>
    <title>Tech Notes - Diagnóstico</title>
</head>
<body>
    <h1>Tech Notes - Diagnóstico</h1>
    <p>Total de notas encontradas: {notes.length}</p>
    <ul>
        {notes.map(note => (
            <li>{note.data.title || note.id}</li>
        ))}
    </ul>
</body>
</html>
ASTROEOF
    
    echo -e "${GREEN}✓${NC} Archivo temporal de diagnóstico creado"
fi

echo ""

# ============================================
# 3. VERIFICAR CONTENT.CONFIG.TS
# ============================================
echo "⚙️  [3/6] Verificando content.config.ts..."
echo ""

if grep -q "tech-notes" src/content.config.ts 2>/dev/null; then
    echo -e "${GREEN}✓${NC} Colección 'tech-notes' encontrada en content.config.ts"
else
    echo -e "${RED}✗${NC} Colección 'tech-notes' NO encontrada en content.config.ts"
    echo "   Mostrando contenido actual:"
    head -20 src/content.config.ts 2>/dev/null || echo "   (archivo no encontrado)"
fi

echo ""

# ============================================
# 4. VERIFICAR ASTRO.CONFIG.MJS
# ============================================
echo "⚙️  [4/6] Verificando astro.config.mjs..."
echo ""

if grep -q "tech-notes" astro.config.mjs 2>/dev/null; then
    echo -e "${GREEN}✓${NC} Referencia a 'tech-notes' encontrada en astro.config.mjs"
    echo "   Líneas relevantes:"
    grep -n -A 2 -B 2 "tech-notes" astro.config.mjs || true
else
    echo -e "${YELLOW}⚠${NC}  No se encontró 'tech-notes' en astro.config.mjs"
    echo "   Esto podría ser normal si se usa enlace directo"
fi

echo ""

# ============================================
# 5. ELIMINAR COLECCIÓN QUESTIONS
# ============================================
echo "🗑️  [5/6] Eliminando colección 'questions'..."
echo ""

if [ -d "src/content/questions" ]; then
    echo -e "${YELLOW}⚠${NC}  Directorio src/content/questions existe"
    read -p "   ¿Deseas eliminarlo? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        rm -rf src/content/questions
        echo -e "${GREEN}✓${NC} Directorio eliminado"
    else
        echo "   Mantenido"
    fi
else
    echo -e "${GREEN}✓${NC} Directorio src/content/questions no existe (ya eliminado)"
fi

# Limpiar referencia en content.config.ts
if grep -q "questions" src/content.config.ts 2>/dev/null; then
    echo -e "${YELLOW}⚠${NC}  Referencia a 'questions' encontrada en content.config.ts"
    echo "   Debes eliminarla manualmente"
else
    echo -e "${GREEN}✓${NC} No hay referencias a 'questions' en content.config.ts"
fi

echo ""

# ============================================
# 6. VERIFICAR NOTAS EXISTENTES
# ============================================
echo "📝 [6/6] Verificando notas existentes..."
echo ""

NOTE_COUNT=$(find src/content/tech-notes -name "*.md" -o -name "*.mdx" 2>/dev/null | wc -l)
echo "   Archivos .md/.mdx encontrados: $NOTE_COUNT"

if [ $NOTE_COUNT -eq 0 ]; then
    echo -e "${YELLOW}⚠${NC}  No hay notas en tech-notes/"
    echo "   ¿Migraste las notas desde docs/notes/?"
else
    echo -e "${GREEN}✓${NC} Notas encontradas:"
    find src/content/tech-notes -name "*.md" -o -name "*.mdx" | head -5
fi

echo ""
echo "===================================="
echo "📊 RESUMEN DEL DIAGNÓSTICO"
echo "===================================="
echo ""

# ============================================
# ANÁLISIS DEL ERROR ESPECÍFICO
# ============================================
echo "🔴 ANÁLISIS DEL ERROR:"
echo ""
echo "Error reportado:"
echo '  [WARN] [router] A `getStaticPaths()` route pattern was matched,'
echo '  but no matching static path was found for requested path `/es/tech-notes/`.'
echo '  Entry docs → 404 was not found.'
echo ""
echo "Causa probable:"
echo "  Starlight está intentando buscar 'tech-notes' en la colección 'docs'"
echo "  en lugar de buscar el archivo src/pages/tech-notes/index.astro"
echo ""
echo "Soluciones posibles:"
echo ""
echo "  A) CREAR src/pages/tech-notes/index.astro"
echo "     Este archivo debe existir para manejar la ruta /tech-notes/"
echo ""
echo "  B) USAR src/pages/tech-notes/[lang].astro"
echo "     Para manejar /es/tech-notes/ y /en/tech-notes/ por separado"
echo ""
echo "  C) CREAR PÁGINAS DE CONTENIDO EN docs/"
echo "     src/content/docs/es/tech-notes.mdx (página de índice)"
echo "     Pero esto no es recomendado para un blog"
echo ""

# ============================================
# GENERAR SOLUCIÓN RECOMENDADA
# ============================================
echo ""
echo "===================================="
echo "✅ SOLUCIÓN RECOMENDADA"
echo "===================================="
echo ""
echo "Ejecuta estos pasos:"
echo ""
echo "1. Asegúrate de tener el archivo src/pages/tech-notes/index.astro"
echo "   (o usa el código de la guía de implementación)"
echo ""
echo "2. Verifica que content.config.ts tiene la colección 'tech-notes'"
echo ""
echo "3. Si usas el sidebar de Starlight para enlazar a tech-notes,"
echo "   asegúrate de que usa 'link' y no 'autogenerate'"
echo ""
echo "Ejemplo correcto en astro.config.mjs:"
echo ""
cat << 'CONFIGEOF'
sidebar: [
  {
    label: 'Tech Notes',
    translations: { es: 'Notas Técnicas' },
    link: '/tech-notes/',  // ← Esto apunta a pages/tech-notes/index.astro
    badge: { text: 'Blog', variant: 'note' }
  },
  // ... resto de configuración
]
CONFIGEOF
echo ""

echo "===================================="
echo "¿Necesitas que cree los archivos faltantes? (y/n)"
read -n 1 -r
echo ""

if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo ""
    echo "Creando archivos de solución..."
    # Aquí se pueden crear los archivos necesarios
    echo "Ejecuta el script de implementación completo para generar todos los archivos"
fi
